from .name_extractor import NameExtractor

__all__ = ["NameExtractor"] 